<?php
session_start();
session_destroy();
header('Location: office_login.php');
?>