<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pocket_study";

$name = $_POST["name"];
$passwd = $_POST["passwd"];

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
	echo "<img src='images/2222.png'></img> Connection Failed </br>";
}else{
	echo "Connected To $dbname </br>";
}

$sql = "SELECT name, password FROM office WHERE name = '".$name."' AND password = '".$passwd."'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        if($name == $row["name"] and $passwd == $row["password"]){
			$_SESSION['office']=$name;
			echo "Logged in";
			header('Location: office first page.php');
			
		}
		else {
			echo "Wrong";
			
		}
    }
	
} else
{
    echo "Wrong";
	header('Location: try_office_login.php');
}

mysqli_close($conn);
?>