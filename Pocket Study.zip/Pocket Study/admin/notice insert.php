<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password,"pocket_study");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}
error_reporting(0);
$ndept=$_POST["ndept"];
$ntitle=$_POST["ntitle"];
$ncontent=$_POST["ncontent"];

$sql = "INSERT INTO notice_board VALUES ('$ndept','$ntitle','$ncontent')";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
	header('location:notice upload.php');
	} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

?>