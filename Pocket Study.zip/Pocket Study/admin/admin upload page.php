<!DOCTYPE html>
<html lang="en">
<?php
session_start();
if(isset($_SESSION['admin'])){
?>
<head>
  <title>ADMIN</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/main.css">
  
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      
      <a class="navbar-brand" href="admin first page.php"><h1 class="header">Pocket Study</h1></a>
    </div>
    
  </div>
</nav>
<br><br><br>


<div class="row"  align="center">
    <div class="col-md-6">
		<button type="button" class="btn btn-default btn-lg" style="min-width:250px; max-width:250px">
			<img src="images/clock.PNG" width="40px" height="40pxpx">
			<br>
			Timetable section
		</button>
	</div>
	
    <div class="col-md-6">
	<button type="button" class="btn btn-default btn-lg" style="min-width:250px; max-width:250px">
		<img src="images/notes.PNG" width="40px"height="40px">
		<br>
		Notes section
    </div>
</div>
<br><br><br>
<div class="row"  align="center">
	<div class="col-md-6">
	<button type="button" class="btn btn-default btn-lg" style="min-width:250px; max-width:250px">
		<img src="images/notice.PNG" width="40px"height="40px">
		<br>
		Notice section
    </div>
	<div class="col-md-6">
	<button type="button" class="btn btn-default btn-lg" style="min-width:250px; max-width:250px">
		<img src="images/results.PNG" width="40px"height="40px">
		<br>
		Result section
    </div>
</div>
<br><br><br>
<div class="row"  align="center">	
	<div class="col-md-6">
	<button type="button" class="btn btn-default btn-lg" style="min-width:250px; max-width:250px">
		<img src="images/syllabus.PNG" width="40px"height="40px">
		<br>
		Syllabus section
    </div>
	
	<div class="col-md-6">
	<button type="button" class="btn btn-default btn-lg" style="min-width:250px; max-width:250px">
		<img src="images/questions_1.PNG" width="40px"height="40px">
		<br>
		Qusestion paper section
    </div>
</div>




</body>
<?php
}
else{
echo 'please log in..';

}
?>
</html >