
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Admin Login Page</title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>

<body class="login">

<div class="loginbox radius">
<h2 style="color:#FFF; text-align:center">Admin Login Form</h2>
	<div class="loginboxinner radius">
    	<div class="loginheader">
    		<h1 class="title">Login</h1>
        	<div class="logo"><img src="images/logo.png" /></div>
    	</div><!--loginheader-->
        
        <div class="loginform">
                	
        	<form id="login" action="admin set.php" method="post">
            	<p>
                	<label for="username" class="bebas">Admin name:</label>
                    <input type="text" id="username" name="name" placeholder="Enter admin name" class="radius2" style="color: black;"/>
                </p>
                <p>
                	<label for="password" class="bebas">Password:</label>
                    <input type="password" id="password" name="passwd" placeholder="Enter password" class="radius2" style="color: black;"/>
                </p>
                <p>
                	<button class="radius title" name="client_login">Login</button>
                </p>
            </form>
        </div><!--loginform-->
    </div><!--loginboxinner-->
</div><!--loginbox-->
<center>Use admin name as admin and password is admin.</center>
</body>

</html>
