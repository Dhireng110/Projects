<html>
<?php
session_start();
if(isset($_SESSION['admin'])){
?>
<head>
  <title>Admin</title>
  <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  
</head>
<body background="images/bg.jpg">
		<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="admin first page.php"><h1 class="header"> Pocket Study</h1></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="dropdown">
         
					<ul class="dropdown-menu">
          
					</ul>
				</li>
        
			</ul>
			<ul class="nav navbar-nav navbar-right">
				
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<h1 class="setting">
							Hi,  <?php echo ($_SESSION['admin']);?>
						</h1>
					</a>
					<ul class="dropdown-menu">
						<li><a href="sessionunsetf1.php" style="color:black">Log out</a></li>
						<li class="divider"></li>
    
  </div>
</nav>
<div class="container">
  <br>
  <div class="page-header">
                    <h2> <font color="black">Notice</font></h2>
                </div>
  <div class="jumbotron">
	<form role="form" action="notice insert.php" method="POST">
	<div class="form-group">
		<label for="sel1">Select Department:</label>
		<select class="form-control" id="sel1" name="ndept">
			<option>COMPUTER</option>
			<option>CIVIL</option>
			<option>MECHANICAL</option>
			<option>ELECTRICAL</option>
			<option>INDUSTRIAL ELECTRONICS</option>
		</select>
	</div>
    <div class="form-group">
      <label for="email">Notice title:</label>
      <input type="text" class="form-control" id="email" placeholder="Enter Notice Title" name="ntitle" >
    </div>
    <div class="form-group">
      <label for="pwd">Notice content:</label>
      <input type="text" class="form-control" id="pwd" placeholder="Enter notice content" name="ncontent">
    </div>
	 <button type="submit" class="btn btn-default">Done</button>
</form>
</body>
<?php
}
else{
echo 'please log in..';

}
?>
</html>