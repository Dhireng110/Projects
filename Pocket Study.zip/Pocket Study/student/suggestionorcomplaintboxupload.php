<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password,"pocket_study");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}
error_reporting(0);
$title1 = $_POST["title"];
$content2 = $_POST["content"];


$user=$_SESSION['name'];
$s=Suggestion;
$c=Complaint;
date_default_timezone_set("Asia/Kolkata");
$result0 = mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$user'");
while($row = mysqli_fetch_array($result0))
		{
			$name=$row['full_name'];
			$dept=$row['dept'];
			$sem=$row['sem'];
			$email=$row['email'];
			$date= date("Y/m/d h:i:sa");
		}
if(isset($_POST['sorc'])) {
    if($_POST['sorc'] == 'sugestion') {
        $sql = "INSERT INTO suggestionsorcomplaints VALUES ('$s','$name','$email','$dept','$sem','$title1','$content2','$date')";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
	header ('Location:sugestionorcompletebox.php');
	
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
    } elseif($_POST['sorc'] == 'complaint') {
        $sql = "INSERT INTO suggestionsorcomplaints VALUES ('$c','$name','$email','$dept','$sem','$title1','$content2','$date')";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
	header ('Location:sugestionorcompletebox.php');
	
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
    }
}
		


?>