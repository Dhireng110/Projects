<?php

// branch on the basis of 'calculate' value 
switch ($_POST['calculate']) {
      // if calculate => add
      case 'FIT':  //1st
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\1st Sem\FIT.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;

      // if calculate => C Programing
      case 'C Programing':  //2nd
			$filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\1st Sem\C Programing.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;

      // if calculate => Applied Physics
      case 'Applied Physics': //3rd
			$filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\1st Sem\Applied Physics.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            break;
	  // if calculate => CAD
      case 'CAD':  //4th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\1st Sem\CAD.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
	  // if calculate => Communication Skills
      case 'Communication Skills':  //5th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\1st Sem\Communication Skills.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
      // if calculate => ECW
      case 'ECW':  //6th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\1st Sem\ECW.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
      // if calculate => Basic Mtahs
      case 'Basic Mtahs':  //7th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\1st Sem\Basic Mtahs.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;			
}

?>