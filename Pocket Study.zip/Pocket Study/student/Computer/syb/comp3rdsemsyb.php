<?php

// branch on the basis of 'calculate' value 
switch ($_POST['calculate']) {
      // if calculate => add
      case 'CN':  //1st
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\2nd Year\3rd sem\CN.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;

      // if calculate => C Programing
      case 'EDC':  //2nd
			$filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\2nd Year\3rd sem\EDC.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;

      // if calculate => Applied Physics
      case 'Engineering Maths': //3rd
			$filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\2nd Year\3rd sem\Engineering Maths.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            break;
	  // if calculate => CAD
      case 'M.T.':  //4th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\2nd Year\3rd sem\M.T.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
	  // if calculate => Communication Skills
      case 'Microprocessor-1':  //5th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\2nd Year\3rd sem\Microprocessor-1.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
      // if calculate => ECW
      case 'RDBMS':  //6th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\2nd Year\3rd sem\RDBMS.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
      // if calculate => Basic Mtahs
      case 'Visual Programming':  //7th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\2nd Year\3rd sem\Visual Programming.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;			
}

?>