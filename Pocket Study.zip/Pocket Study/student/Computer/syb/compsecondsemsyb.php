<html>
<?php
session_start();
if(isset($_SESSION['name'])){
?>
<head>

  <title>Pocket Signup</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="css/main.css"></link>
  
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="../../viewf1.php"><h1 class="header"> Pocket Study</h1></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="dropdown">
         
					<ul class="dropdown-menu">
          
					</ul>
				</li>
        
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="../../questionpaperdivider.php"><h1 class="setting">Question papers</h1></a></li>
				<li><a href="../../notesdivider.php"><h1 class="setting">Notes</h1></a></li>
				<li><a href="../../retnotice.php"><h1 class="setting">Notice</h1></a></li>
				<li><a href="../../syllabusdivider.php"><h1 class="setting">Syallbus</h1></a></li>
				<li><a href="../../memof1.php"><h1 class="setting">Memo</h1></a></li>
				<li><a href="../../timetabledivider.php"><h1 class="setting">Time table</h1></a></li>
				<li><a href="../../resultdivider.php"><h1 class="setting">Results</h1></a></li>
				<li><a href="../../chatroomdivider.php"><h1 class="setting">Chat Room</h1></a></li>
				<li><a href="../../formsf1.php"><h1 class="setting">Upload</h1></a></li>
				<li><a href="../../onlineapply.php"><h1 class="setting">Online Apply</h1></a></li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<h1 class="setting">
							Hi,  <?php echo ($_SESSION['name']);?>
						</h1>
					</a>
					<ul class="dropdown-menu">
						<li><a href="../../unsetf1.php" style="color:black">Log out</a></li>
						<li class="divider"></li>             
					</ul>
				</li>
			</ul>
		</div>
	</div>
</nav>
<br><br><br>
<div class="container">
	<ul class="nav nav-tabs">
		<li><a href="compfirstsemsyb.php">Semester 1</a></li>
		<li><a href="compsecondsemsyb.php">Semester 2</a></li>
		<li><a href="compthirdsemsyb.php">Semester 3</a></li>
		<li><a href="compfourthsemsyb.php">Semester 4</a></li>
		<li><a href="compfifthsemsyb.php">Semester 5</a></li>
		<li><a href="compsixthsemsyb.php">Semester 6</a></li>
	</ul>

	<form method="POST" action="comp2ndsemsyb.php">
		<h3>Applied Maths:</h3><br>
			<button type="submit" name="calculate" value="Applied Maths">Download</button> 
			<br>
		<h3>BDE:</h3>
		<br>
			<button type="submit" name="calculate" value="BDE">Download</button> 
			<br>
		<h3>BEE:</h3>
			<button type="submit" name="calculate" value="BEE">Download</button>
			<br>
		<h3>C++:</h3><br>
			<button type="submit" name="calculate" value="C++">Download</button>
			<br>
		<h3>Communication Practise:</h3><br>
			<button type="submit" name="calculate" value="Communication Practise">Download</button>
			<br>
		<h3>DGS-1:</h3><br>
			<button type="submit" name="calculate" value="DGS-1">Download</button> 
			<br>
		<h3>Web Designing:</h3><br>
			<button type="submit" name="calculate" value="Web Designing">Download</button> 
	</form>
</div>
</body>
<?php
}
else{
echo 'please log in..';

}
?>	

</html>