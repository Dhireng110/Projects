<?php

// branch on the basis of 'calculate' value 
switch ($_POST['calculate']) {
      // if calculate => add
      case 'Adanced Computer Communication':  //1st
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\3rd Year\6th Sem\Advanced Computer Communication.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;

      // if calculate => C Programing
      case 'Embedded Systems':  //2nd
			$filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\3rd Year\6th Sem\Embedded Systems.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;

      // if calculate => Applied Physics
      case 'ENTREPRENEURSHIP DEVELOPMENT': //3rd
			$filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\3rd Year\6th Sem\ENTREPRENEURSHIP DEVELOPMENT.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            break;
	  // if calculate => CAD
      case 'INFORMATION SYSTEM SECURITY':  //4th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\3rd Year\6th Sem\INFORMATION SYSTEM SECURITY.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
	  // if calculate => Communication Skills
      case 'MICROPROCESSORS II':  //5th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\3rd Year\6th Sem\MICROPROCESSORS II.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
      // if calculate => ECW
      case 'NETWORK ADMINISTRATION':  //6th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\3rd Year\6th Sem\NETWORK ADMINISTRATION.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
      // if calculate => Basic Mtahs
      case 'SEMINAR':  //7th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\3rd Year\6th Sem\SEMINAR .pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;			
}

?>