<?php

// branch on the basis of 'calculate' value 
switch ($_POST['calculate']) {
      // if calculate => add
      case 'Applied Maths':  //1st
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\2nd Sem\Applied Maths.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;

      // if calculate => C Programing
      case 'BDE':  //2nd
			$filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\2nd Sem\BDE.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;

      // if calculate => Applied Physics
      case 'BEE': //3rd
			$filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\2nd Sem\BEE.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            break;
	  // if calculate => CAD
      case 'C++':  //4th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\2nd Sem\C++.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
	  // if calculate => Communication Skills
      case 'Communication Practise':  //5th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\2nd Sem\Communication Practise.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
      // if calculate => ECW
      case 'DGS-1':  //6th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\2nd Sem\DGS-1.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;
      // if calculate => Basic Mtahs
      case 'Web Designing':  //7th
			 $filePath = 'C:\xampp\htdocs\uploads\syallbus\Computer Syllabus\1st Year\2nd Sem\Web Designing.pdf';

    if(file_exists($filePath)) {
        $fileName = basename($filePath);
        $fileSize = filesize($filePath);

        // Output headers.
        header("Cache-Control: private");
        header("Content-Type: application/stream");
        header("Content-Length: ".$fileSize);
        header("Content-Disposition: attachment; filename=".$fileName);
		
		

        // Output file.
        readfile ($filePath);                   
        exit();
    }
    else {
        die('The provided file path is not valid.');
    }
            
            break;			
}

?>