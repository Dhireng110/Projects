<html>
<?php
	session_start();
	if(isset($_SESSION['name'])){
?>
<head>
  <title>pocket study</title>
  <link rel="stylesheet" media="(max-width: 1000px)" href="css/max-640px.css"></link><!--for iphone -->
  <link rel="stylesheet" media="(min-width: 1000px)" href="css/min-640px.css"></link><!--for web -->
  <link rel="stylesheet" media="(max-width: 910px)" href="css/min-900px.css"></link><!--for moto e -->
  <link rel="stylesheet" media="(max-width: 920px)" href="css/min-930px.css"></link><!--for moto e 2-->
   
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/Main.css"></link>

</head>

<body>
<div>
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="viewf1.php"><h1 class="header"> Pocket Study</h1></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        
        <li class="dropdown">
         
          <ul class="dropdown-menu">
          
          </ul>
        </li>
        
      </ul>
			<ul class="nav navbar-nav navbar-right">
				<li>
					<a href="#">
						<h1 class="setting">
							Settings
						</h1>
					</a>
				</li>
				<li>
					<a href="#">
						<h1 class="setting">
							Contact us
						</h1>
					</a>
				</li>
				<li>
					<a href="#">
						<h1 class="setting">
							About us
						</h1>
					</a>
				</li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<h1 class="setting">
							Hi,  <?php echo ($_SESSION['name']);?>
						</h1>
					</a>
					<ul class="dropdown-menu">
						<li><a href="unsetf1.php" style="color:black">Log out</a></li>
						<li class="divider"></li>             
					</ul>
				</li>
			</ul>
		</div>
	</div>
	</nav>
</div>
<br><br>
<div class="box-set">
	<center>
		<a href="timetabledivider.php" style="color:white">
			<figure class="box"><img src="images/clock.PNG" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Timetable</h4>
			</figure>
		</a>
		<a href="syllabusdivider.php" style="color:white">
			<figure class="box"><img src="images/notes.PNG" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Notes</h4>
			</figure>
		</a>
		<a href="retnotice.php" style="color:white">
			<figure class="box"><img src="images/notice.PNG" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Notice</h4>
			</figure>
		</a>
		<a href="syllabusdivider.php" style="color:white">
			<figure class="box"><img src="images/syllabus.PNG" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Syllabus</h4>
			</figure>
		</a>
		<a href="syllabusdivider.php" style="color:white">
			<figure class="box"><img src="images/questions_1.PNG" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Question Paper</h4>
			</figure>
		</a>
		<a href="resultdivider.php" style="color:white">
			<figure class="box"><img src="images/results.PNG" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Result</h4>
			</figure>
		</a>
		<a href="memof1.php" style="color:white">
			<figure class="box"><img src="images/memo.PNG" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Memo</h4>
			</figure>
		</a>
		<a href="onlineapply.php" style="color:white">
			<figure class="box"><img src="images/online_apply.PNG" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Apply for Documents</h4>
			</figure>
		</a>
		<a href="formsf1.php" style="color:white">
			<figure class="box"><img src="images/upload.PNG" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Upload</h4>
			</figure>
		</a>
		<a href="chatdivider.php" style="color:white">
			<figure class="box"><img src="images/images.png" alt="HTML5 Icon" style="width:100px;height:100px">
				<br>
				<h4>Chat room</h4>
			</figure>
		</a>
		<a href="sugestionorcompletebox.php" style="color:white">
			<figure class="box">
			<br>
				<h4>Do you want to say/ask something? </h4>
			</figure>
		</a>
	</center>
	<br>
	<br>	  
</div>
</body>


<?php
}
else{
echo 'please log in..';

}
?>

</html>