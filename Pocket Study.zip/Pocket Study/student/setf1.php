<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pocket_study";

$email = $_POST["email"];
$passwd = $_POST["passwd"];


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
	echo "<img src='images/2222.png'></img> Connection Failed </br>";
}else{
	echo "Connected To $dbname </br>";
}
$sql = "SELECT email, password FROM users WHERE email = '".$email."' AND password = '".$passwd."'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        if($email == $row["email"] and $passwd == $row["password"]){
			$_SESSION['name']=$email;
			echo "Logged in";
			header('Location: viewf1.php');
			
		}
		else {
			echo "Wrong";
			
		}
    }
	
} else
{
    echo "Wrong";
	header('Location: tryagainlogin.php');
}

mysqli_close($conn);
?>