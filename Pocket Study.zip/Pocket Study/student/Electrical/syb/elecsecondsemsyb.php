<html>
<?php
session_start();
if(isset($_SESSION['name'])){
?>
<head>

  <title>Pocket Signup</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="css/main.css"></link>
  
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="../../viewf1.php"><h1 class="header"> Pocket Study</h1></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="dropdown">
         
					<ul class="dropdown-menu">
          
					</ul>
				</li>
        
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="../../questionpaperdivider.php"><h1 class="setting">Question papers</h1></a></li>
				<li><a href="../../notesdivider.php"><h1 class="setting">Notes</h1></a></li>
				<li><a href="../../retnotice.php"><h1 class="setting">Notice</h1></a></li>
				<li><a href="../../syllabusdivider.php"><h1 class="setting">Syallbus</h1></a></li>
				<li><a href="../../memof1.php"><h1 class="setting">Memo</h1></a></li>
				<li><a href="../../timetabledivider.php"><h1 class="setting">Time table</h1></a></li>
				<li><a href="../../resultdivider.php"><h1 class="setting">Results</h1></a></li>
				<li><a href="../../chatroomdivider.php"><h1 class="setting">Chat Room</h1></a></li>
				<li><a href="../../formsf1.php"><h1 class="setting">Upload</h1></a></li>
				<li><a href="../../onlineapply.php"><h1 class="setting">Online Apply</h1></a></li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<h1 class="setting">
							Hi,  <?php echo ($_SESSION['name']);?>
						</h1>
					</a>
					<ul class="dropdown-menu">
						<li><a href="../../unsetf1.php" style="color:black">Log out</a></li>
						<li class="divider"></li>             
					</ul>
				</li>
			</ul>
		</div>
	</div>
</nav>
<br><br><br>
<div class="container">
	<ul class="nav nav-tabs">
		<li><a href="elecfirstsemsyb.php">Semester 1</a></li>
		<li><a href="elecsecondsemsyb.php">Semester 2</a></li>
		<li><a href="electhirdsemsyb.php">Semester 3</a></li>
		<li><a href="elecfourthsemsyb.php">Semester 4</a></li>
		<li><a href="elecfifthsemsyb.php">Semester 5</a></li>
		<li><a href="elecsixthsemsyb.php">Semester 6</a></li>
	</ul>

	<form method="POST" action="elec2ndsemsyb.php">
		<h3>FIT:</h3><br>
			<button type="submit" name="calculate" value="FIT">Download</button>  
			<br>
		<h3>C Programing:</h3>
		<br>
			<button type="submit" name="calculate" value="C Programing">Download</button>  
			<br>
		<h3>Applied Physics:</h3>
			<button type="submit" name="calculate" value="Applied Physics">Download</button> 
			<br>
		<h3>CAD:</h3><br>
			<button type="submit" name="calculate" value="CAD">Download</button> 
			<br>
		<h3>Communication Skills:</h3><br>
			<button type="submit" name="calculate" value="Communication Skills">Download</button> 
			<br>
		<h3>ECW:</h3><br>
			<button type="submit" name="calculate" value="ECW">Download</button>  
			<br>
		<h3>Basic Mtahs:</h3><br>
			<button type="submit" name="calculate" value="Basic Mtahs">Download</button> 
	</form>
</div>
</body>
<?php
}
else{
echo 'please log in..';

}
?>
</html>