<html>
<head></head><body>
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password,"pocket_study");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}
error_reporting(0);
$user=$_SESSION['name'];
$result0 = mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$user'");
while($row = mysqli_fetch_array($result0))
		{
			$br=$row['dept'];
			$sem=$row['sem'];
		}
		echo $br;
		echo $sem;
		if($br=="COMPUTER")
		{
		 if($sem=="FIRST"){
			header('Location: Computer\syb\compfirstsemsyb.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Computer\syb\compsecondsemsyb.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Computer\syb\compthirdsemsyb.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Computer\syb\compfourthsemsyb.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Computer\syb\compfifthsemsyb.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Computer\syb\compsixthsemsyb.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="CIVIL")
		{
			if($sem=="FIRST"){
			header('Location: Civil\syb\civilfirstsemsyb.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Civil\syb\civilsecondsemsyb.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Civil\syb\civilthirdsemsyb.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Civil\syb\civilfourthsemsyb.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Civil\syb\civilfifthsemsyb.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Civil\syb\civilsixthsemsyb.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="MECHANICAL")
		{
		 if($sem=="FIRST"){
			header('Location: Machanical\syb\mechfirstsemsyb.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Machanical\syb\mechsecondsemsyb.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Machanical\syb\mechthirdsemsyb.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Machanical\syb\mechfourthsemsyb.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Machanical\syb\mechfifthsemsyb.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Machanical\syb\mechsixthsemsyb.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="ELECTRICAL")
		{
		 if($sem=="FIRST"){
			header('Location: Electrical\syb\elecfirstsemsyb.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Electrical\syb\elecsecondsemsyb.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Electrical\syb\electhirdsemsyb.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Electrical\syb\elecfourthsemsyb.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Electrical\syb\elecfifthsemsyb.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Electrical\syb\elecsixthsemsyb.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="INDUSTRIAL ELECTRONICS")
		{
		 if($sem=="FIRST"){
			header('Location: Industrial\syb\indfirstsemsyb.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Industrial\syb\indsecondsemsyb.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Industrial\syb\indthirdsemsyb.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Industrial\syb\indfourthsemsyb.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Industrial\syb\indfifthsemsyb.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Industrial\syb\insixthsemsyb.php');
			}
			else
			{
			echo "wrong";
			}
		}
		
		else
		{
			echo "sorry invalid entry";	
		}
?>
</body>
</html>