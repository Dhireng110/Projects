<?php
$servername = "localhost";
$username = "root";
$password = "";

$fullname = $_POST["fullname"];
$enrollmentno = $_POST["enrollmentno"];
$email = $_POST["email"];
$certificate = $_POST["certificate"];
$reason = $_POST["reason"];
$recptno = $_POST["recptno"];
$phone = $_POST["phone"];
$selectdept = $_POST["selectdept"];


// Create connection
$conn = mysqli_connect($servername, $username, $password,"pocket_study");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}

$sql = "INSERT INTO online_apply VALUES ('$fullname','$enrollmentno','$email','$certificate','$reason','$recptno','$phone','$selectdept')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

?>