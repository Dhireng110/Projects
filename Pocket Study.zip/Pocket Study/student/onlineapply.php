<html lang="en">
<head>
  <title>Pocket Signup</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="css/main.css"></link>
  
</head>
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="feature.html"><h1 class="header"> Pocket Study</h1></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        
        <li class="dropdown">
         
          <ul class="dropdown-menu">
          
          </ul>
        </li>
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
             <li><a href="#"><h1 class="setting">Question papers</h1></a></li>
			<li><a href="#"><h1 class="setting">Notes</h1></a></li>
			<li><a href="#"><h1 class="setting">Syallbus</h1></a></li>
			<li><a href="#"><h1 class="setting">Memo</h1></a></li>
			<li><a href="#"><h1 class="setting">Time table</h1></a></li>
			<li><a href="#"><h1 class="setting">Results</h1></a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container">
<br><br>
   <div class="page-header">
                    <h2>ONLINE APPLY</h2>
                </div>
  <div class="jumbotron">
	<form role="form"action="online_apply.php" method="POST">
	 <div class="form-group">
      <label for="name">Full Name:</label>
      <input type="name" class="form-control" id="name" placeholder="Full name" name="fullname">
    </div>
	<div class="form-group">
      <label for="enrollmentno">Enrollment No:</label>
      <input type="text" class="form-control" id="enrollmentno" placeholder="Enrollment No" name="enrollmentno">
    </div>
    <div class="form-group">
      <label for="email">Email Id:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter Email id" name="email">
    </div>
	
	<div class="form-group">
      <label for="text">Certificate:</label>
      <input type="text" class="form-control" id="Certificate" placeholder="Enter Certificate Name" name="certificate">
    </div>
	<div class="form-group">
      <label for="email">Reason For Applying:</label>
      <textarea class="form-control" id="Reason" placeholder="Reason" name="reason"></textarea>
	 
    </div>
	<div>
	<label for="text">Fee Recipt no:</label>
      <input type="text" class="form-control" id="Recept_no" placeholder="Fee Recipt no.:" name="recptno">
	  </div>
	  <br>
	   <div class="form-group">
      <label for="text">Phone no(for notifiaction):</label>
      <input type="text" class="form-control" id="Phone_no" placeholder="Enter Phone no.:" name="phone">
    </div>
	<div>
	    <label for="selectdept">Select Dept:</label>
        
            <input type="text" class="form-control" placeholder="Select Dept" name="selectdept">
    </div><br>
	<button type="submit" class="btn btn-default">Done</button>
    </div>
   
    
    
  </form> 	
  </div>
  
</div>

</body>
</html>
