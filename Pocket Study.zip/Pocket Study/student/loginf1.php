
<html>
	<?php
		session_start();
		if(isset($_SESSION['name'])){
			header('Location: viewf1.php');
		}else{
	?>
<head>
  <title>Pocket login</title>
  <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap1.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  
</head>
<body background="images/bg.jpg">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      
      <a class="navbar-brand" href="index.html"><h1 class="header">Pocket Study</h1></a>
    </div>
    
  </div>
</nav>
<div class="container">
  <br>
  <div class="page-header">
                    <h2> <font color="blue">Login </font></h2>
                </div>
  <div class="jumbotron">
	<form role="form" action="setf1.php" method="POST">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" >
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="passwd">
    </div>
    <div class="forgot Password">
      <a href="#"> <label>Forgot Password</label></a>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
	<br>
	 <div>
      <a href="pocketsignupf1.php"> <u><b><p align="right">Signup</b></u></a>
    </div>
	
	<!--<button type="submit" class="btn btn-default"><a href="pocketsignupf1.php" style="color:black">Create New</a></button>-->
  </form> 
  </div>
  
</div>

</body>
<?php
}
?>
</html>

