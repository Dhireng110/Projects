<?php
$servername = "localhost";
$username = "root";
$password = "";

$fullname = $_POST["fullname"];
$enrollmentno = $_POST["enrollmentno"];
$reciptno = $_POST["reciptno"];
$selectdept = $_POST["selectdept"];
$selectsem = $_POST["selectsem"];
$email = $_POST["email"];
$passwd = $_POST["passwd"];

// Create connection
$conn = mysqli_connect($servername, $username, $password,"pocket_study");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}

$sql = "INSERT INTO users VALUES ('$fullname','$enrollmentno','$reciptno','$selectdept','$selectsem','$email','$passwd')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
	header('Location: loginf1.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}




?>
