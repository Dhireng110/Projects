<html>
<head></head><body>
<?php
$servername = "localhost";
$username = "root";
$password = "";




$conn = mysqli_connect($servername, $username, $password,"pocket_study");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}
error_reporting(0);
session_start();
$user=$_SESSION['name'];
$result0 = mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$user'");$i=0;
while($row = mysqli_fetch_array($result0))
	  {
	  	$br=$row['dept'];
		

	  }
	  echo "<form action=test2.php method=post><button type=submit class=btn btn-success name=view value=$br>View</button></form>";

	  

		echo $br;


?>
</body>
</html>