<!DOCTYPE html>
<html lang="en">
<head>
  <title>ADMIN</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/main.css">
  
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      
      <a class="navbar-brand" href="pocket_main.html"><h1 class="header">Pocket Study</h1></a>
    </div>
    
  </div>
</nav>
<br><br><br>
<img src="images/timetable.jpg" class="img-thumbnail" alt="Responsive image">
<br><br>
<center>
 <button type="submit" class="btn btn-default"><img src="images/download.PNG" width="40px" height="40pxpx">Download</button>
 </center>
<br><br><br><br><br><br>
</body></html>