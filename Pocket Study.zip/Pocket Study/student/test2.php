<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
<link rel="stylesheet" href="dist/css/bootstrap.min.css">
<style type="text/css">
body { background: #edf0f5 ; }
.page-header { background-color: #f58634; margin-left: 0px; margin-right: 0px; };
</style>
<title>--Notice Board--</title>
</head>
<body>
<div class="page-header">
<div class="logo-img"><center>
<a href="HODDashboard.php"><img class="img-responsive" src="Logo.png" height=50 width=250 /></a>
<h3>Notice Board</h3>
</center>
</div>
</div>
<div class="container"> 
<div class="jumbotron">
<?php
$servername = "localhost";
$username = "root";
$password = "";




$conn = mysqli_connect($servername, $username, $password,"pocket_study");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}
error_reporting(0);
$til=$_REQUEST['view'];
$t=urldecode($til);
$result= mysqli_query($conn,"SELECT * FROM `notices` WHERE `titile`='$t'");
$i=0;
while($row = mysqli_fetch_array($result))
{
	$title=$row["title"];
	$notice=$row["notice"];
	$file=$row["file"];
}
if($file=="")
{
echo "<label>Title:</label><br>";echo $t;echo "<br><hr>";
echo "<label>Notice: </label><br>";echo $notice;echo "<br><hr>";
}
else
{
echo "<label>Title:</label><br>";echo $title;echo "<br><hr>";
echo "<label>Notice: </label><br>";echo $notice;echo "<br><hr>";
echo "<label>Attached File :</label>";echo "<a href=$file>Attached Notice</a>";
}
?>
</div>
</div>
<script src="dist/js/bootstrap.min.js"></script>
</body>
</html>
