<html>
<head></head><body>
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password,"pocket_study");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}
error_reporting(0);
$user=$_SESSION['name'];
$result0 = mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$user'");
while($row = mysqli_fetch_array($result0))
		{
			$br=$row['dept'];
			$sem=$row['sem'];
		}
		echo $br;
		echo $sem;
		if($br=="COMPUTER")
		{
		 if($sem=="FIRST"){
			header('Location: Computer\chat\chat1\chat.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Computer\chat\chat1\chat.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Computer\chat\chat2\chat.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Computer\chat\chat2\chat.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Computer\chat\chat3\chat.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Computer\chat\chat3\chat.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="CIVIL")
		{
			if($sem=="FIRST"){
			header('Location: Civil\chat\chat1\chat.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Civil\chat\chat1\chat.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Civil\chat\chat2\chat.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Civil\chat\chat2\chat.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Civil\chat\chat3\chat.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Civil\chat\chat3\chat.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="MECHANICAL")
		{
		 if($sem=="FIRST"){
			header('Location: Machanical\chat\chat1\chat.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Machanical\chat\chat1\chat.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Machanical\chat\chat2\chat.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Machanical\chat\chat2\chat.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Machanical\chat\chat3\chat.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Machanical\chat\chat3\chat.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="ELECTRICAL")
		{
		 if($sem=="FIRST"){
			header('Location: Electrical\chat\chat1\chat.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Electrical\chat\chat1\chat.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Electrical\chat\chat2\chat.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Electrical\chat\chat2\chat.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Electrical\chat\chat3\chat.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Electrical\chat\chat3\chat.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="INDUSTRIAL ELECTRONICS")
		{
		 if($sem=="FIRST"){
			header('Location: Industrial\chat\chat1\chat.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Industrial\chat\chat1\chat.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Industrial\chat\chat2\chat.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Industrial\chat\chat2\chat.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Industrial\chat\chat3\chat.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Industrial\chat\chat3\chat.php');
			}
			else
			{
			echo "wrong";
			}
		}
		
		else
		{
			echo "sorry invalid entry";	
		}
?>
</body>
</html>