
<html>
<?php
session_start();
if(isset($_SESSION['name'])){
header('Location: viewf1.php');
}else{
?>
<head>
  <title>Pocket Signup</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap1.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="css/pocketlogin.css"></link>
  
</head>
<body background="images/bg.jpg">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      
      <a class="navbar-brand" href="index.html"><h1 class="header">Pocket Study</h1></a>
    </div>
    
  </div>
</nav>
<div class="container">
<br><br>
   <div class="page-header">
                    <h2>Sign up</h2>
                </div>
  <div class="jumbotron">
	<form role="form" action="signupf1.php" method="POST">
	 <div class="form-group">
      <label for="name">Full Name:</label>
      <input type="name" class="form-control" id="name" placeholder="Full name" name="fullname"
	  required data-fv-notempty-message="The first name is required and cannot be empty">
    </div>
	<div class="form-group">
      <label for="enrollmentno">EnrollMent No:</label>
      <input type="text" class="form-control" id="enrollmentno" placeholder="EnrollMent no" name="enrollmentno">
    </div>
	<div class="form-group">
      <label for="enrollmentno">First Year Fee Recipt No:</label>
      <input type="text" class="form-control" id="feereciptno" placeholder="Fee Recipt no" name="reciptno">
    </div>
	<div class="form-group">
		<label for="sel1">Select Department:</label>
		<select class="form-control" id="sel1" name="selectdept">
			<option>COMPUTER</option>
			<option>CIVIL</option>
			<option>MECHANICAL</option>
			<option>ELECTRICAL</option>
			<option>INDUSTRIAL ELECTRONICS</option>
		</select>
	</div>
	<div class="form-group">
		<label for="sel1">Select Semister:</label>
		<select class="form-control" id="sel1" name="selectsem">
			<option>FIRST</option>
			<option>SECOND</option>
			<option>THIRD</option>
			<option>FOURTH</option>
			<option>FIFTH</option>
			<option>SIXTH</option>
		</select>
	</div>
	
	<br>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
	
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="passwd">
	  <span class="help-block">Minimum 8 character.</span>
    </div>
	 <div class="form-group">
      <label for="pwd">Confirm Password:</label>
      <input type="password" class="form-control" id="confmpwd" placeholder="Re-enter password" name="confirmpasswd">
    </div>
    <div class="checkbox">
    <label><input type="checkbox">Accept terms and conditions</label>
  </div>
    <button type="submit" class="btn btn-default">Done</button>
	<br><br>
	I have register already take me to <a href="loginf1.php">Login</a> page.
  </form> 
  </div>
  
</div>

</body>
<?php
}
?>
</html>

