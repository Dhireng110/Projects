<?php
$servername = "localhost";
$username = "root";
$password = "";

$memo = $_POST["memo"];
$memocontent = $_POST["memocontent"]

$conn = mysqli_connect($servername, $username, $password,"pocket_study");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}

error_reporting(0);
$user=$_SESSION['name'];
$result0 = mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$user'");
while($row = mysqli_fetch_array($result0))
		{
			$name=$row['full_name'];
			$dept=$row['dept'];
			$sem=$row['sem'];
		}

		
$sql = "INSERT INTO memo VALUES ('$name','$dept','$sem','$memo','$memocontent')";