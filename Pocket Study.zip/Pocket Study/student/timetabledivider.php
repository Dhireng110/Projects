<html>
<head></head><body>
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password,"pocket_study");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
echo "Connected successfully<br>";}
error_reporting(0);
$user=$_SESSION['name'];
$result0 = mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$user'");
while($row = mysqli_fetch_array($result0))
		{
			$br=$row['dept'];
			$sem=$row['sem'];
		}
		echo $br;
		echo $sem;
		if($br=="COMPUTER")
		{
		 if($sem=="FIRST"){
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="CIVIL")
		{
			if($sem=="FIRST"){
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="MECHANICAL")
		{
		 if($sem=="FIRST"){
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="ELECTRICAL")
		{
		 if($sem=="FIRST"){
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			else
			{
			echo "wrong";
			}
		}
		else if($br=="INDUSTRIAL ELECTRONICS")
		{
		 if($sem=="FIRST"){
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SECOND")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="THIRD")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FOURTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="FIFTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			elseif($sem=="SIXTH")
			{
			header('Location: Computer\time\timetable.php');
			}
			else
			{
			echo "wrong";
			}
		}
		
		else
		{
			echo "sorry invalid entry";	
		}
?>
</body>
</html>