<html>
<?php
session_start();
if(isset($_SESSION['name'])){
?>
<head>
  <title>Pocket login</title>
  <link href="css/main.css" rel="stylesheet">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap1.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  
</head>
<body background="images/bg.jpg">
<div>
	<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="viewf1.php"><h1 class="header"> Pocket Study</h1></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="dropdown">
         
					<ul class="dropdown-menu">
          
					</ul>
				</li>
        
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="syllabusdivider.php"><h1 class="setting">Question papers</h1></a></li>
				<li><a href="syllabusdivider.php"><h1 class="setting">Notes</h1></a></li>
				<li><a href="retnotice.php"><h1 class="setting">Notice</h1></a></li>
				<li><a href="syllabusdivider.php"><h1 class="setting">Syallbus</h1></a></li>
				<li><a href="memof1.php"><h1 class="setting">Memo</h1></a></li>
				<li><a href="timetabledivider.php"><h1 class="setting">Time table</h1></a></li>
				<li><a href="resultdivider.php"><h1 class="setting">Results</h1></a></li>
				<li><a href="chatdivider.php""><h1 class="setting">Chat Room</h1></a></li>
				<li><a href="formsf1.php"><h1 class="setting">Upload</h1></a></li>
				<li><a href="onlineapply.php"><h1 class="setting">Online Apply</h1></a></li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<h1 class="setting">
							Hi,  <?php echo ($_SESSION['name']);?>
						</h1>
					</a>
					<ul class="dropdown-menu">
						<li><a href="unsetf1.php" style="color:black">Log out</a></li>
						<li class="divider"></li>             
					</ul>
				</li>
			</ul>
		</div>
	</div>
</nav>
</div>

    

<div class="container">
<div class="jumbotron"><br><br>
  <label for="name">The Result will be shown as soon as displayed.......:</label>
  

  </div></div>
</body>
<?php
}
else{
echo 'please log in..';

}
?>
</html>