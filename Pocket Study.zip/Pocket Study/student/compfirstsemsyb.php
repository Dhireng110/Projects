<html>
<?php
session_start();
if(isset($_SESSION['name'])){
?>
<head>

  <title>Pocket Signup</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="css/main.css"></link>
  
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="feature.html"><h1 class="header"> Pocket Study</h1></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="dropdown">
         
					<ul class="dropdown-menu">
          
					</ul>
				</li>
        
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#"><h1 class="setting">Question papers</h1></a></li>
				<li><a href="#"><h1 class="setting">Notes</h1></a></li>
				<li><a href="#"><h1 class="setting">Syallbus</h1></a></li>
				<li><a href="#"><h1 class="setting">Memo</h1></a></li>
				<li><a href="#"><h1 class="setting">Time table</h1></a></li>
				<li><a href="#"><h1 class="setting">Results</h1></a></li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<h1 class="setting">
							Hi,  <?php echo ($_SESSION['name']);?>
						</h1>
					</a>
					<ul class="dropdown-menu">
						<li><a href="unsetf1.php" style="color:black">Log out</a></li>
						<li class="divider"></li>             
					</ul>
				</li>
			</ul>
		</div>
	</div>
</nav>
<br><br><br>
<div class="container">
	<ul class="nav nav-tabs">
		<li><a href="#">Semister 1</a></li>
		<li><a href="#">Semister 2</a></li>
		<li><a href="#">Semister 3</a></li>
		<li><a href="#">Semister 4</a></li>
		<li><a href="#">Semister 5</a></li>
		<li><a href="#">Semister 6</a></li>
	</ul>

	<form method="POST" action="temp.php">
		<h1>FIT:</h1><br>
			<input type="submit" name="calculate" value="FIT"> 
			<br>
		<h1>C Programing:</h1>
		<br>
			<input type="submit" name="calculate" value="C Programing"> 
			<br>
		<h1>Applied Physics:</h1>
			<input type="submit" name="calculate" value="Applied Physics">
			<br>
		<h1>CAD:</h1><br>
			<input type="submit" name="calculate" value="CAD">
			<br>
		<h1>Communication Skills:</h1><br>
			<input type="submit" name="calculate" value="Communication Skills">
			<br>
		<h1>ECW:</h1><br>
			<input type="submit" name="calculate" value="ECW"> 
			<br>
		<h1>Basic Mtahs:</h1><br>
			<input type="submit" name="calculate" value="Basic Mtahs"> 
	</form>
</div>
</body>
<?php
}
else{
echo 'please log in..';

}
?>
</html>