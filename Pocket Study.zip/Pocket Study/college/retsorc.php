<html>
<?php
	session_start();
	if(isset($_SESSION['college'])){
		
?>
<head>
  <title>pocket study</title>
   
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/Main.css"></link>

</head>

<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="college first page.php"><h1 class="header"> Pocket Study</h1></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="dropdown">
         
					<ul class="dropdown-menu">
          
					</ul>
				</li>
        
			</ul>
			<ul class="nav navbar-nav navbar-right">
				
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<h1 class="setting">
							Hi, This college login.
						</h1>
					</a>
					<ul class="dropdown-menu">
						<li><a href="sessionunsetf1.php" style="color:black">Log out</a></li>
						<li class="divider"></li>
    
  </div>
</nav>
<br><br><br>

<div class="container">
<p><h1><center>Suggestions or Complaints</center></h1></p><hr width="70%" height="20%">
<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password,"pocket_study");

// Check connection
//if (!$conn) {
//    die("Connection failed: " . mysqli_connect_error());
//}else{
//echo "Connected successfully<br>";}
//error_reporting(0);
$i=0;
$row;
//date_default_timezone_set("Asia/Kolkata");		
$result1=mysqli_query($conn,"SELECT * FROM `suggestionsorcomplaints`");
while($row = mysqli_fetch_array($result1))
        {
			$name=$row['name'];
			$d=$row['date'];
			$sorc=$row['sorc'];
			$t=$row['title'];
			$c=$row['content'];
			$sem=$row['sem'];
			$dept=$row['dept'];
			$i++;
			
			echo "<b>";
			echo $i;
			echo ". ";
			echo "</b>";
			echo "Name of content: ";
			echo "<b>";
			echo $sorc;
			echo "</b>";
			echo "<br>";
			echo "by ";
			echo "<b>";
			echo $name;
			echo "</b>";
			echo " ";
			echo $sem;
			echo " Semister ";
			echo $dept;
			echo " Department.";
			echo "<br>";
			echo "on ";
			echo "<b>";
			echo $d;
			echo "</b>";
			echo "<br>";
			echo "Title of content: ";
			echo "<b>";
			echo $t;
			echo "</b>";
			echo "<br>";
			echo "Content: ";
			echo "<b>";
			echo $c;
			echo "</b>";
			echo "<hr>";
			
		}
		
		
?>
</div>
</body>
<?php
}
else{
echo 'please log in..';

}
?>
</html>