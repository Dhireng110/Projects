<html>
<?php
	session_start();
	if(isset($_SESSION['college'])){
		
?>
<head>
  <title>pocket study</title>
   
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/Main.css"></link>

</head>

<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>                        
			</button>
			<a class="navbar-brand" href="viewf1.php"><h1 class="header"> Pocket Study</h1></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<li class="dropdown">
         
					<ul class="dropdown-menu">
          
					</ul>
				</li>
        
			</ul>
			<ul class="nav navbar-nav navbar-right">
				
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<h1 class="setting">
							Hi, This college login.
						</h1>
					</a>
					<ul class="dropdown-menu">
						<li><a href="sessionunsetf1.php" style="color:black">Log out</a></li>
						<li class="divider"></li>
    
  </div>
</nav>
<br><br><br>

<div class="container">
<?php
//session_start();
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password,"pocket_study");

// Check connection
//if (!$conn) {
//    die("Connection failed: " . mysqli_connect_error());
//}else{
//echo "Connected successfully<br>";}
//error_reporting(0);
$i=0;
date_default_timezone_set("Asia/Kolkata");		
$result1=mysqli_query($conn,"SELECT * FROM `online_apply`");
while($row = mysqli_fetch_array($result1))
		{
			$name=$row['fullname'];
			$noticetitle=$row['certificate'];
			$noticecontent=$row['reason'];
			$enrollmentno=$row['enrollmentno'];
			$i++;
			
			$date= date("Y/m/d h:i:sa");
			echo $date;
			echo "<br>";
			echo "<br>";
			echo $i;
			echo "<br>";
			echo "<p>";
			echo "Name of Student: ";
			echo "<b>";
			echo $name;
			echo "</b>";
			echo "</p>";
			echo "<br>";
			echo "<p>";
			echo "Enrollment no of Student: ";
			echo "<b>";
			echo $enrollmentno;
			echo "</b>";
			echo "</p>";
			echo "<br>";
			echo "<p>";
			echo "Name of Document: ";
			echo "<b>";
			echo $noticetitle;
			echo "</b>";
			echo "</p>";
			echo "<br>";
			echo "<p>";
			echo "Reason for Document: ";
			echo "<b>";
			echo $noticecontent;
			echo "</b>";
			echo "</p>";
			echo "<br>";
			echo "<hr>";
		}
		
?>
</div>
</body>
<?php
}
else{
echo 'please log in..';

}
?>
</html>