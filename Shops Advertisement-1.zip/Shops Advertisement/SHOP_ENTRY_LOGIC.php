<?php
include('dbcon.php');
session_start();
error_reporting(0);
if(isset($_SESSION['employee'])){

$shopkeepername= $_SESSION['employee'];

$getid=mysqli_query($conn,"select id from shopkeeperinfo where name='$shopkeepername'");
if($getid)
{
	while($row=mysqli_fetch_array($getid))
	{
		$shopkeeper_id= $row['id'];
		
	}
}
$shopname=$_POST["shopname"];
$shopnumber= $_POST["shopnumber"];
$shopaddress = $_POST["shopaddress"];
$product= $_POST["product"];
$category= $_POST["category"];
$location = $_POST["location"];
$dob = $_POST["dob"];

$insertquery="INSERT INTO `shop info`(`shopid`, `shop name`, `shop address`, `shop licence no`, `specialinfo`, `shopkepeer_id`, `location_id`, `category_id`) VALUES ('','$shopname','$shopaddress','$shopnumber','$product','$shopkeeper_id','$location','$category')";
if(mysqli_query($conn,$insertquery))
{
?>
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New Shop a E-Commerce Online Shopping Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
<!--css-->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet">
<!--css-->
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="New Shop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

<script src="js/jquery.min.js"></script>
<link href='//fonts.googleapis.com/css?family=Cagliostro' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,600,400italic,300italic,300' rel='stylesheet' type='text/css'>
<!--search jQuery-->
	<script src="js/main.js"></script>
<!--search jQuery-->
<script src="js/responsiveslides.min.js"></script>

 <!--mycart-->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
 <!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
  <!--start-rate-->

<!--//End-rate-->
</head>
<body>

<div class="header-top">
				<div class="container">
					<div class="top-left">
						<h3><a href="#"> Advertising Network</a></h3>
					</div>
					<div class="top-right">
					<ul>
						<li><a href="SHOPKEEPER_LOGOUT.php"><h3>Logout</h3></a></li>
						<li><a href="SHOPKEEPER_SIGNUP.php"> <h3>Shopkeeper's Account</h3> </a></li>
					</ul>
					
					</div>
			</div>
</div>	
<br>
<div class="container">
            <form class="form-horizontal" role="form" action="SHOP_ENTRY_LOGIC.php" method="post">
                <h1>Your Shop Advertise is Posted.</h1><br>
<?php
}
}
else
{
	echo "please Login First";
}