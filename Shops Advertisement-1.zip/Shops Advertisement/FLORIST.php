<html>
<head>
<title>New Shop a E-Commerce Online Shopping Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
<!--css-->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet">
<!--css-->
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="New Shop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

<script src="js/jquery.min.js"></script>
<link href='//fonts.googleapis.com/css?family=Cagliostro' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,600,400italic,300italic,300' rel='stylesheet' type='text/css'>
<!--search jQuery-->
	<script src="js/main.js"></script>
<!--search jQuery-->
<script src="js/responsiveslides.min.js"></script>

 <!--mycart-->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
 <!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
  <!--start-rate-->

<!--//End-rate-->
</head>
<body>

<div class="header">
			<div class="header-top">
				<div class="container">
					<div class="top-left">
						<h3><a href="index1.html"> Advertising Network</a></h3>
					</div>
					<div class="top-right">
					<ul>
						<li><a href="login.html"><h3>Login</h3></a></li>
						<li><a href="SHOPKEEPER_SIGNUP.php"> <h3>Shopkeeper's Account</h3> </a></li>
					</ul>
					
					</div>
			</div>
</div>	
<div class="banner-w3">
			<div class="demo-1">            
				<div id="example1" class="core-slider core-slider__carousel example_1">
					<div class="core-slider_viewport">
						<div class="core-slider_list">
							<div class="core-slider_item">
								<img src="images/b1.jpg" class="img-responsive" alt="">
							</div>
							 <div class="core-slider_item">
								 <img src="images/b2.jpg" class="img-responsive" alt="">
							 </div>
							<div class="core-slider_item">
								  <img src="images/b3.jpg" class="img-responsive" alt="">
							</div>
							<div class="core-slider_item">
								  <img src="images/b4.jpg" class="img-responsive" alt="">
							</div>
						 </div>
					</div>
					<div class="core-slider_nav">
						<div class="core-slider_arrow core-slider_arrow__right"></div>
						<div class="core-slider_arrow core-slider_arrow__left"></div>
					</div>
					<div class="core-slider_control-nav"></div>
				</div>
			</div><br><br>
			
			<link href="css/coreSlider.css" rel="stylesheet" type="text/css">
			<script src="js/coreSlider.js"></script>
			<script>
			$('#example1').coreSlider({
			  pauseOnHover: false,
			  interval: 3000,
			  controlNavEnabled: true
			});

			</script>
<?php
include('dbcon.php');
$getshops= mysqli_query($conn,"select * from `shop info` where category_id='6'");
if($getshops)
{
	while($row= mysqli_fetch_array($getshops))
	{
		$name= $row['shop name'];
		$address= $row['shop address'];
		$number = $row['shop licence no'];
		$products= $row['specialinfo'];
		$shopkeeper_id = $row['shopkepeer_id'];
		$location_id = $row['location_id'];
		$category_id = $row['category_id'];
		$getlocation= mysqli_query($conn,"select location_name from location where  id ='$location_id' ");
			if($getlocation)
			{
				while($row=mysqli_fetch_array($getlocation))
				{
					$location_name = $row['location_name'];					
				}
			}
			$getowner= mysqli_query($conn,"select name from shopkeeperinfo where  id ='$shopkeeper_id' ");
			if($getowner)
			{
				while($row=mysqli_fetch_array($getowner))
				{
					$owner = $row['name'];					
				}
			}
	echo "<div class='col-md-4 latest-grid'>
							<div class='latest-top'>
								<img  src='images/florist.jpg' class='img-responsive'  alt='' width='300' height='300'></div></div>";
		echo "<h3> Name of Shop:&nbsp &nbsp  &nbsp &nbsp $name";
		echo "<br>";
		echo "<h3>Address of Shop :&nbsp &nbsp$address";
		echo "<br>";
		echo "<h3>Shop Licence Number: &nbsp$number";
		echo "<br>";
		echo "<h3>Special Products: &nbsp$products";
		echo "<br>";
		echo "<h3>Shop Location:&nbsp &nbsp $location_name";
		echo "<br>";
		echo "<h3>Shop Owner:&nbsp &nbsp $owner";
		echo "<br><br><br>";
		
	}
}



?>




<br><br>
<br><br><br><br>
		</div>
			<div class="footer-w3l">
						<div class="container">
							<div class="footer-grids">
								<div class="col-md-3 footer-grid">
									<h4>About </h4>
									<p>Advertising Network is for advertisements of the shops.it provides platform for shopkeeper's to advertise their shops.</p>
									
								</div>
								<div class="col-md-3 footer-grid">
									<h4>My Account</h4>
									<ul>
										
										<li><a href="login.html">Login</a></li>
										<li><a href="registered.html"> Create Account </a></li>
									</ul>
								</div>
								<div class="col-md-3 footer-grid">
									<h4>Information</h4>
									<ul>
										<li><a href="index.html">Home</a></li>
										<li><a href="mail.html">Mail Us</a></li>
									
									</ul>
								</div>
								<div class="col-md-3 footer-grid foot">
									<h4>Contacts</h4>
									<ul>
										
										<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i><a href="#">9967886868</a></li>
										<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:example@mail.com"> dhireng110@gmail.com</a></li>
										
									</ul>
								</div>
							<div class="clearfix"> </div>
							</div>
							
						</div>
					</div>
</html>