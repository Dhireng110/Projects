<?php
session_start();
include('dbcon.php');
$name=$_POST["name"];
$password=$_POST["password"];

$sql = "SELECT name, password FROM shopkeeperinfo WHERE name = '".$name."' AND password = '".$password."'";
$result = mysqli_query($conn, $sql);
error_reporting(0);
if (mysqli_num_rows($result)>0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result))
	{
        if($name == $row["name"] and $password == $row["password"])
		{
			$_SESSION['employee']=$name;
			header('Location:SHOP_ENTRY.php');
			
		}
		else 
		{
			echo "Wrong ID or Password";
			
		}
    }
	
} 
else
{
    echo "Wrong";
}

mysqli_close($conn);


?>