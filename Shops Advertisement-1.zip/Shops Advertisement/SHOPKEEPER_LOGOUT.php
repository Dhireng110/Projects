<?php
session_start();
session_destroy();
header('Location:SHOPKEEPER_LOGIN.php');
?>