<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New Shop a E-Commerce Online Shopping Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
<!--css-->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet">
<!--css-->
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="New Shop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

<script src="js/jquery.min.js"></script>
<link href='//fonts.googleapis.com/css?family=Cagliostro' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,600,400italic,300italic,300' rel='stylesheet' type='text/css'>
<!--search jQuery-->
	<script src="js/main.js"></script>
<!--search jQuery-->
<script src="js/responsiveslides.min.js"></script>

 <!--mycart-->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
 <!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
  <!--start-rate-->

<!--//End-rate-->
</head>
<body>

<div class="header-top">
				<div class="container">
					<div class="top-left">
						<h3><a href="index1.html"> Advertising Network</a></h3>
					</div>
					<div class="top-right">
					<ul>
						<li><a href="SHOPKEEPER_LOGIN.php"><h3>Login</h3></a></li>
						<li><a href="SHOPKEEPER_SIGNUP.php"> <h3>Shopkeeper's Account</h3> </a></li>
					</ul>
					
					</div>
			</div>
</div>	
<br>
<div class="container">
            <form class="form-horizontal" role="form" action="SHOPKEEPER_SIGNUP_LOGIC.php" method="post">
                <h1>Shopkeeper Registration Form</h1><br>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Full Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" placeholder="Name" class="form-control" name="name"autofocus>
                        
                    </div>
                </div>
				<div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="password" placeholder="Password" class="form-control" name="password">
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Phone</label>
                    <div class="col-sm-9">
                        <input type="number" id="email" placeholder="Phone" class="form-control" name="phone">
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" id="email" placeholder="Email" class="form-control" name="email">
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Date Of Birth</label>
                    <div class="col-sm-9">
                        <input type="date" id="dob" placeholder="name" class="form-control" name="dob">
                    </div>
                </div>
                

		<div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
						
                    </div>
                </div>
            </form>
			
		</body>
		</html>