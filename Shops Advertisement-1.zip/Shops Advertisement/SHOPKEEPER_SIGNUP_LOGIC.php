<?php
include('dbcon.php');
$name=$_POST["name"];
$password=$_POST["password"];
$phone=$_POST["phone"];
$email=$_POST["email"];
$dob=$_POST["dob"];


$insert_record="INSERT INTO `shopkeeperinfo`(`id`, `name`, `password`, `phone no`, `email`, `dob`) VALUES ('','$name','$password','$phone','$email','$dob')";

if (mysqli_query($conn, $insert_record)) 
{
	header('Location: SHOPKEEPER_LOGIN.php');
	
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


?>