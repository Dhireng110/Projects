<?php
include('dbcon.php');
session_start();
if(isset($_SESSION['employee'])){
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New Shop a E-Commerce Online Shopping Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
<!--css-->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet">
<!--css-->
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="New Shop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

<script src="js/jquery.min.js"></script>
<link href='//fonts.googleapis.com/css?family=Cagliostro' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,600,400italic,300italic,300' rel='stylesheet' type='text/css'>
<!--search jQuery-->
	<script src="js/main.js"></script>
<!--search jQuery-->
<script src="js/responsiveslides.min.js"></script>

 <!--mycart-->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
 <!-- cart -->
<script src="js/simpleCart.min.js"></script>
<!-- cart -->
  <!--start-rate-->

<!--//End-rate-->
</head>
<body>

<div class="header-top">
				<div class="container">
					<div class="top-left">
						<h3><a href="index1.html"> Advertising Network</a></h3>
					</div>
					<div class="top-right">
					<ul>
						<li><a href="SHOPKEEPER_LOGOUT.php"><h3>Logout</h3></a></li>
						<li><a href="SHOPKEEPER_SIGNUP.php"> <h3>Shopkeeper's Account</h3> </a></li>
					</ul>
					
					</div>
			</div>
</div>	
<br>
<div class="container">
            <form class="form-horizontal" role="form" action="SHOP_ENTRY_LOGIC.php" method="post">
                <h1>ADVERTISE YOUR SHOPS</h1><br>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Shopname</label>
                    <div class="col-sm-9">
                        <input type="text"  placeholder="Shopname" class="form-control" name="shopname"autofocus>
                    </div>
                </div>
			<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Shop Licence Number</label>
                    <div class="col-sm-9">
                        <input type="number"  placeholder="Shop Licence Number" class="form-control" name="shopnumber"autofocus>
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Shop Adress</label>
                    <div class="col-sm-9">
                        <input type="text"  placeholder="Shop Address" class="form-control" name="shopaddress">
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Special Products of Shops</label>
                    <div class="col-sm-9">
                        <input type="text"  placeholder="Special products" class="form-control" name="product">
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Shop Category</label>
					<div class="col-sm-9"><br>
					<select name="category">
					<option value="1">Jwellery Shops</option>
					<option value="2">Clothing Stores</option>
					<option value="3">General Shops</option>
					<option value="4">Watch Shops</option>
					<option value="5">Electronic Shops</option>
					<option value="6">Florist Shops</option>
					</select>
					</div></div>
					<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Shop Location</label>
					<div class="col-sm-9"><br>
					<select name="location">
					<option value="1">Mulund</option>
					<option value="2">Nahur</option>
					<option value="3">Bhandup</option>
					<option value="4">Kanjur Marg</option>
					<option value="5">Vikhroli</option>
					<option value="6">Ghatkoper</option>
					<option value="7">Kurla</option>
					<option value="8">Sion</option>
					</select>
					</div></div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Date Of opening of Shop</label>
                    <div class="col-sm-9">
                        <input type="date" id="dob" placeholder="name" class="form-control" name="dob">
                    </div>
                </div>
                

		<div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
						
                    </div>
                </div>
            </form>
			
		</body>
		</html>
<?php
}
else
{
	echo "please Login First";
}